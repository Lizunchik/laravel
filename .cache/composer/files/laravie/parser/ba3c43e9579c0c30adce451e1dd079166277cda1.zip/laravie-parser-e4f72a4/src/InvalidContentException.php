<?php

namespace Laravie\Parser;

class InvalidContentException extends \InvalidArgumentException
{
    //
}
