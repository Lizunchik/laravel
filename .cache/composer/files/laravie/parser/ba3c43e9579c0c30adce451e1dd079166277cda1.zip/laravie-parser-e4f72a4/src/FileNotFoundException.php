<?php

namespace Laravie\Parser;

class FileNotFoundException extends \InvalidArgumentException
{
    //
}
