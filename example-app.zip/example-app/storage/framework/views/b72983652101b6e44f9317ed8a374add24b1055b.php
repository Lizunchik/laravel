<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?> Список новостей - ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>

	<!-- Page Heading -->
	<?php 
		 var_dump($newsList);
		 ?>
	<div class="d-sm-flex align-items-center justify-content-between mb-4">
		<h1 class="h3 mb-0 text-gray-800">Список новостей</h1>
		<a href="<?php echo e(route('admin.news.create')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
					class="fas fa-plus fa-sm text-white-50"></i> Добавить новость</a>
	</div>
<div class="row">
<div class="col-md-12">
<div class="table-responsive">
 <table class="table table-bordered">
	<thead>
	 <tr>
	  <th>#ID</th>
	  <th>Заголовок</th>
	  <th>Описание</th>
	  <th>Дата добавления</th>
	  <th>Управление</th>
	 </tr>
	</thead>

		 <tbody>

		 <?php $__empty_1 = true; $__currentLoopData = $newsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		 <tr>
			 <td><?php echo e($news['id']); ?></td>
			 <td><?php echo e($news['title']); ?></td>
			 <td><?php echo $news['description']; ?></td>
			 <td><?php echo e($news['created_at']); ?></td>
			 <td>
				  <a href="<?php echo e(route('admin.news.edit', ['news' => $news['id']])); ?>">Ред.</a>
				  &nbsp;
				  <a href="">Уд.</a>
			 </td>
		 </tr>
		 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			 <h2>Новостей нет</h2>
		 <?php endif; ?>
		 </tbody>

 </table>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/news/index.blade.php ENDPATH**/ ?>