<?php $__env->startSection('content'); ?>

<div class="col-lg-6">
    <?php $__empty_1 = true; $__currentLoopData = $newsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="card mb-4">
        <a href="<?php echo e(route('news.show', ['id' => $news['id']])); ?>">
            <img class="card-img-top" src="https://dummyimage.com/700x350/dee2e6/6c757d.jpg" alt="..." /></a>
        <div class="card-body">
            <div class="small text-muted"><?php echo e(now()->format('d-m-Y H:i')); ?></div>
            <h2 class="card-title h4"><?php echo e($news['title']); ?></h2>
            <p class="card-text"><?php echo $news['description']; ?></p>
            <a class="btn btn-primary" href="<?php echo e(route('news.show', ['id' => $news['id']])); ?>">Читать далее →</a>
        </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h2>Записей нет</h2>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/news/index.blade.php ENDPATH**/ ?>